-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2019 at 02:56 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sample_project2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_controller`
--

CREATE TABLE `tbl_controller` (
  `cont_id` int(11) NOT NULL,
  `cont_menu_id` int(11) NOT NULL,
  `cont_breadcrumb` text COLLATE utf8_unicode_ci NOT NULL,
  `cont_folder` text COLLATE utf8_unicode_ci NOT NULL,
  `cont_page` text COLLATE utf8_unicode_ci NOT NULL,
  `cont_visibility` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_controller`
--

INSERT INTO `tbl_controller` (`cont_id`, `cont_menu_id`, `cont_breadcrumb`, `cont_folder`, `cont_page`, `cont_visibility`, `created_by`, `created_on`) VALUES
(1, 1, 'list of members', 'modules/member/', 'list.php', 1, 0, '2019-05-29 09:46:34'),
(2, 2, 'member addition scrren', 'modules/member/', 'add.php', 1, 0, '2019-05-29 09:46:34'),
(3, 3, 'member edit screen', 'modules/member/', 'edit.php', 1, 0, '2019-05-29 09:46:34'),
(4, 4, 'member delete scrren', 'modules/member/', 'delete.php', 1, 0, '2019-05-29 09:46:34'),
(5, 5, 'member search scrren', 'modules/member/', 'search.php', 1, 0, '2019-05-29 09:46:34'),
(6, 6, 'list of members hobby', 'modules/member_hobby/', 'list.php', 1, 0, '2019-05-29 09:46:34'),
(7, 7, 'member addition hobby scrren', 'modules/member_hobby/', 'add.php', 1, 0, '2019-05-29 09:46:34'),
(8, 9, 'member edit hobby screen', 'modules/member_hobby/', 'edit.php', 1, 0, '2019-05-29 09:46:34'),
(9, 10, 'member hobby delete scrren', 'modules/member_hobby/', 'delete.php', 1, 0, '2019-05-29 09:46:34'),
(10, 8, 'member hobby search scrren', 'modules/member_hobby/', 'search.php', 1, 0, '2019-05-29 09:46:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `login_id_pk` int(11) NOT NULL,
  `user_name` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member_hobby`
--

CREATE TABLE `tbl_member_hobby` (
  `hobby_id` int(11) NOT NULL,
  `hobby_detail` text COLLATE utf8_unicode_ci NOT NULL,
  `member_id_fk` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visibility` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_member_hobby`
--

INSERT INTO `tbl_member_hobby` (`hobby_id`, `hobby_detail`, `member_id_fk`, `created_by`, `created_on`, `visibility`) VALUES
(1, 'Cricket', 1, 0, '2019-05-29 10:30:36', 1),
(2, 'Watching Movies', 2, 0, '2019-05-29 10:21:43', 1),
(3, 'Eating', 3, 0, '2019-05-29 10:29:05', 1),
(4, 'Riding', 4, 0, '2019-05-29 10:21:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member_master`
--

CREATE TABLE `tbl_member_master` (
  `member_id_pk` int(11) NOT NULL,
  `member_name` text COLLATE utf8_unicode_ci NOT NULL,
  `member_address` text COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visibility` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_member_master`
--

INSERT INTO `tbl_member_master` (`member_id_pk`, `member_name`, `member_address`, `created_by`, `created_on`, `visibility`) VALUES
(1, 'Pradeepkumar', '				Tirupur	', 0, '2019-05-29 10:21:30', 1),
(2, 'Marimuthu', '				Theni	', 0, '2019-05-29 10:20:29', 1),
(3, 'Shivashankar', '		Coimbatore			', 0, '2019-05-29 10:21:17', 1),
(4, 'Sivashankar', '				Palladam	', 0, '2019-05-29 10:21:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` text COLLATE utf8_unicode_ci NOT NULL,
  `menu_icon` text COLLATE utf8_unicode_ci NOT NULL,
  `menu_parent` int(11) NOT NULL,
  `menu_title` text COLLATE utf8_unicode_ci NOT NULL,
  `menu_visibility` text COLLATE utf8_unicode_ci NOT NULL,
  `menu_order` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`menu_id`, `menu_name`, `menu_icon`, `menu_parent`, `menu_title`, `menu_visibility`, `menu_order`, `created_on`, `created_by`) VALUES
(1, 'Member list', 'fa fa-list-alt', 0, 'List Of Members', '1', 2, '2019-05-29 12:13:37', 0),
(2, 'Member Add', 'fa fa-plus', 0, 'Add Members', '1', 1, '2019-05-29 12:12:08', 0),
(5, 'Member Search', 'fa fa-search', 0, 'Search Members', '1', 3, '2019-05-29 12:12:18', 0),
(6, 'Member Hobbies List', 'fa fa-list-alt', 0, 'List Of Member Hobbies', '1', 4, '2019-05-29 12:13:59', 0),
(7, 'Member Hobby Add', 'fa fa-plus', 0, 'Add Members Hobby', '1', 5, '2019-05-29 12:12:02', 0),
(8, 'Member Hobby Search', 'fa fa-search', 0, 'Search Member Hobby', '1', 6, '2019-05-29 12:12:24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project_details`
--

CREATE TABLE `tbl_project_details` (
  `def_types` text COLLATE utf8_unicode_ci NOT NULL,
  `def_value` text COLLATE utf8_unicode_ci NOT NULL,
  `id_pk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_project_details`
--

INSERT INTO `tbl_project_details` (`def_types`, `def_value`, `id_pk`) VALUES
('login_title', 'Member | Login ', 1),
('dashboard_title', 'Member Management', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_controller`
--
ALTER TABLE `tbl_controller`
  ADD PRIMARY KEY (`cont_id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`login_id_pk`);

--
-- Indexes for table `tbl_member_hobby`
--
ALTER TABLE `tbl_member_hobby`
  ADD PRIMARY KEY (`hobby_id`);

--
-- Indexes for table `tbl_member_master`
--
ALTER TABLE `tbl_member_master`
  ADD PRIMARY KEY (`member_id_pk`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tbl_project_details`
--
ALTER TABLE `tbl_project_details`
  ADD PRIMARY KEY (`id_pk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_controller`
--
ALTER TABLE `tbl_controller`
  MODIFY `cont_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `login_id_pk` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_member_hobby`
--
ALTER TABLE `tbl_member_hobby`
  MODIFY `hobby_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_member_master`
--
ALTER TABLE `tbl_member_master`
  MODIFY `member_id_pk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_project_details`
--
ALTER TABLE `tbl_project_details`
  MODIFY `id_pk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
