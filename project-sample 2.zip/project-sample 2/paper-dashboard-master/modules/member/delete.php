<?php
$errorMessage="";


						
if(isset($_POST['btnCreate']))
{
	$memberName=$_POST['txtName'];
	$memberAddress=$_POST['txtAddress'];
	
	
	$updateQuery="update tbl_member_master set visibility=0 where member_id_pk='".$_POST['txtdelete_pk']."'";
	$con->query($updateQuery);
	?>
	<script>window.location="index.php?page=1";</script>
	<?php
	
	
}

function checkMemberExists($memberName,$con)
{
	$exists=0;
	$memcountsql = "select count(*)as membercount from tbl_member_master where member_name='".$memberName."'";
						$memcountresult = $con->query($memcountsql);

						
						while($memcountrow = $memcountresult->fetch_assoc()) 
						{
							if($memcountrow['membercount']>0)
							{
								$exists=1;
							}
						}
						
						
						return $exists;
}
?>
<div class="col-sm-12 mb-3 mb-sm-0">
<?php 
				  if($errorMessage!="")
				  {
						echo $errorMessage	;				  
				  }
				  ?>
				<form method="POST" >
                <div class="form-group row">
				<?php
				$memcountsql = "select * from tbl_member_master where member_id_pk='".$_POST['txtdelete_pk']."'";
				$memcountresult = $con->query($memcountsql);
				if ($memcountresult->num_rows > 0) 
				{
				while($memcountrow = $memcountresult->fetch_assoc()) 
				{
				
				?>
				  <input type="hidden" name="txtdelete_pk" id="txtdelete_pk" value="<?php echo $memcountrow['member_id_pk'];?>">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user" id="txtName" name="txtName" placeholder="First Name" value="<?php echo $memcountrow['member_name'];?>">
                  </div>
                  <div class="col-sm-6">
                    <textarea class="form-control form-control-user" id="txtAddress" name="txtAddress" placeholder="Last Name"><?php echo $memcountrow['member_address'];?></textarea>
                  </div>
				  <?php
				  }
				}
				  ?>
                </div>
               
                <button class="btn btn-primary btn-user btn-block" name="btnCreate">
                  Delete Member
                </button>
                <hr>
               
              </form>
			  </div>