<?php
$errorMessage="";
if(isset($_POST['btnCreate']))
{
	$memberName=$_POST['txtName'];
	$memberAddress=$_POST['txtAddress'];
	
	if(checkMemberExists($memberName,$con) ==0)
	{
	$insertQuery="insert into tbl_member_master(member_name,member_address) values('".$memberName."','".$memberAddress."')";
	$con->query($insertQuery);
	$errorMessage='<div class="card mb-4 py-3 border-left-success">
                <div class="card-body">
                  Member added successfully
                </div>
              </div>';
	}
	else
	{
	$errorMessage='<div class="card mb-4 py-3 border-left-danger">
                <div class="card-body">
                  Member already exists
                </div>
              </div>';
	}
}

function checkMemberExists($memberName,$con)
{
	$exists=0;
	$memcountsql = "select count(*)as membercount from tbl_member_master where member_name='".$memberName."'";
						$memcountresult = $con->query($memcountsql);

						
						while($memcountrow = $memcountresult->fetch_assoc()) 
						{
							if($memcountrow['membercount']>0)
							{
								$exists=1;
							}
						}
						
						
						return $exists;
}
?>
<div class="col-sm-12 mb-3 mb-sm-0">
<?php 
				  if($errorMessage!="")
				  {
						echo $errorMessage	;				  
				  }
				  ?>
			<form method="POST" >
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user" id="txtName" name="txtName" placeholder="First Name">
                  </div>
                  <div class="col-sm-6">
                    <textarea class="form-control form-control-user" id="txtAddress" name="txtAddress" placeholder="Last Name">
					</textarea>
                  </div>
                </div>
               
                <button class="btn btn-primary btn-user btn-block" name="btnCreate">
                  Create Member
                </button>
                <hr>
               
             </form>
</div>