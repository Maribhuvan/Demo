<div class="col-sm-12 mb-3 mb-sm-0">
<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">
			  <a href="index.php?page=2" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                      <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">Add</span>
                  </a>
			  </h6>
            </div>
            <div class="card-body">
				<?php
				$searchValue="";
				  if(isset($_POST['txtsearch']))
				  {
					  $searchValue=$_POST['txtsearch'];
				  }
				  ?>
				 <div class="table-responsive">
					<form method="post" >
					
				<input type="text" id="txtsearch" name="txtsearch" value="<?php echo $searchValue;?>"><button >Search</button></form>
					<a href="index.php?page=5">Clear</a>
				 </div>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Member Name</th>
                      <th>Address</th>
                      <th>Operations</th>
                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Member Name</th>
                      <th>Address</th>
                      <th>Operations</th>
                      
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php
				  
				  $memcountsql = "select * from tbl_member_master where visibility=1 and member_name like '%".$searchValue."%';";
				  $memcountresult = $con->query($memcountsql);

				 if ($memcountresult->num_rows > 0) 
						{
							while($memcountrow = $memcountresult->fetch_assoc()) 
							{
								echo '<tr>
								  <td>'.$memcountrow['member_name'].'</td>
								  <td>'.$memcountrow['member_address'].'</td>
								  <td>
								  <form method="post" action="index.php?page=3">
								  <button class="btn btn-warning btn-circle">
									<i class="fa fa-edit"></i>
								  </button>
								  <input type="hidden" name="txtedit_pk" id="txtedit_pk" value="'.$memcountrow['member_id_pk'].'">
								  </form><br>
								   <form method="post" action="index.php?page=4">
								  <button class="btn btn-danger btn-circle">
									<i class="fa fa-trash"></i>
								  </button>
								  <input type="hidden" name="txtdelete_pk" id="txtdelete_pk" value="'.$memcountrow['member_id_pk'].'">
								  </form>
								  </td>
								  
								</tr>';
							}
						}
				  ?>
                    
                   
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  </div>
		    <!-- Page level plugins -->
  