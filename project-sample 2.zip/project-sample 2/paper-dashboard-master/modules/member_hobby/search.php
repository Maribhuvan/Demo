<div class="col-sm-12 mb-3 mb-sm-0">
<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">
			  <a href="index.php?page=7" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                      <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">Add</span>
                  </a>
			  </h6>
            </div>
            <div class="card-body">
				<?php
				$searchValue="";
				  if(isset($_POST['txtsearch']))
				  {
					  $searchValue=$_POST['txtsearch'];
				  }
				  ?>
				 <div class="table-responsive">
					<form method="post">
						<input type="text" id="txtsearch" name="txtsearch" value="<?php echo $searchValue;?>"><button >Search</button>
					</form>
					<a href="index.php?page=8">Clear</a>
				 </div>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Member Name</th>
                      <th>Hobbies</th>
                      <th>Operations</th>
                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Member Name</th>
                      <th>Hobbies</th>
                      <th>Operations</th>
                      
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php
				  
				  $memsearchsql = "select * from tbl_member_hobby where hobby_detail like '%".$searchValue."%' and visibility=1";        
				  $memsearchresult = $con->query($memsearchsql);

				 if ($memsearchresult->num_rows > 0) 
						{
							while($memsearchrow = $memsearchresult->fetch_assoc()) 
							{

								$memnamesql = "select member_name from tbl_member_master where member_id_pk=
								'".$memsearchrow['member_id_fk']."'";
				  				$memberNameResult = $con->query($memnamesql);
				  				$memberName = mysqli_fetch_assoc($memberNameResult);

								echo '<tr>
								  <td>'.$memberName['member_name'].'</td>
								  <td>'.$memsearchrow['hobby_detail'].'</td>
								  <td>
								  <form method="post" action="index.php?page=9">
								  <button class="btn btn-warning ">
									<i class="fa fa-edit"></i>
								  </button>
								  <input type="hidden" name="txtedit_pk" id="txtedit_pk" value="'.$memsearchrow['hobby_id'].'">
								  </form><br>
								   <form method="post" action="index.php?page=10">
								  <button class="btn btn-danger">
									<i class="fa fa-trash"></i>
								  </button>
								  <input type="hidden" name="txtdelete_pk" id="txtdelete_pk" 
								  value="'.$memsearchrow['hobby_id'].'">
								  </form>
								  </td>
								  
								</tr>';
							}
						}
				  ?>
                    
                   
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  </div>
		    <!-- Page level plugins -->
  