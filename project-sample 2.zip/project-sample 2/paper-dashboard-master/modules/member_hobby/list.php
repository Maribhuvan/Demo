<div class="col-sm-12 mb-3 mb-sm-0">
<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">
			  <a href="index.php?page=7" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                      <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">Add</span>
                  </a>
			  </h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Member Name</th>
                      <th>Hobbies</th>
                      <th>Operations</th>
                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Member Name</th>
                      <th>Hobbies</th>
                      <th>Operations</th>
                      
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php
				  $memcountsql = "select * from tbl_member_hobby where visibility =1;";
				  $memcountresult = $con->query($memcountsql);
				 
			 		if ($memcountresult->num_rows > 0) 
						{
							while($memcountrow = $memcountresult->fetch_assoc()) 
							{
								$memnamesql = "select member_name from tbl_member_master where member_id_pk=
								'".$memcountrow['member_id_fk']."' and visibility=1";
				  				$memberNameResult = $con->query($memnamesql);
				  				$memberName = mysqli_fetch_assoc($memberNameResult);

								echo '<tr>
								  <td>'.$memberName['member_name'].'</td>
								  <td>'.$memcountrow['hobby_detail'].'</td>
								  <td>
									  <form method="post" action="index.php?page=9">
										  <button class="btn btn-warning">
											<i class="fa fa-edit"></i>
										  </button>
									  	<input type="hidden" name="txtedit_pk" id="txtedit_pk" value="'.$memcountrow['hobby_id'].'">
									  </form><br>
									   <form method="post" action="index.php?page=10">
										  <button class="btn btn-danger">
											<i class="fa fa-trash"></i>
										  </button>
										  <input type="hidden" name="txtdelete_pk" id="txtdelete_pk" value="'.$memcountrow['hobby_id'].'">
									  </form>
								  </td>
								  
								</tr>';
							}
						}
				  ?>
                    
                   
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  </div>
		    <!-- Page level plugins -->
  