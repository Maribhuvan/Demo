<?php
$errorMessage="";						
	if(isset($_POST['btnCreate']))
	{
		$memberId=$_POST['memberId'];
		$hobbyDetail=$_POST['hobbyDetail'];		
		
		$updateQuery="update tbl_member_hobby set member_id_fk='".$memberId."',hobby_detail='".$hobbyDetail."' where hobby_id='".$_POST['txtedit_pk']."'";
		$con->query($updateQuery);
		$errorMessage='	<div class="card mb-4 py-3 border-left-success">
	            			<div class="card-body">Hobbies updated successfully</div>
	              		</div>';	
	}
?>
<div class="col-sm-12 mb-3 mb-sm-0">
<?php 
	if($errorMessage!="")
	{
		echo $errorMessage	;				  
	}
?>
	<form method="POST" >
        <div class="form-group row">
			<?php
				
					$memcountsql = "select * from tbl_member_hobby where hobby_id='".$_POST['txtedit_pk']."'";
					$memcountresult = $con->query($memcountsql);
					if ($memcountresult->num_rows > 0) 
					{
						while($memcountrow = $memcountresult->fetch_assoc()) 
						{
			?>
						<input type="hidden" name="txtedit_pk" id="txtedit_pk" value="<?php echo $memcountrow['hobby_id'];?>">
				      	<div class="col-sm-6 mb-3 mb-sm-0" style="margin-top:10px;">
				      		
				      		<select class="form-control form-control-user" id="memberId" name="memberId" value="<?php echo $memcountrow['member_id'];?>">
				      			<option>--Select--</option>
				      			<?php
				      			$query = "SELECT member_name,member_id_pk FROM tbl_member_master;";
								$memberResult = $con->query($query);
								if($memberResult->num_rows > 0)
								{
									while ($row = mysqli_fetch_assoc($memberResult))
									{
										if($memcountrow['member_id_fk'] == $row['member_id_pk'])
										{
											echo "<option selected value='".$row['member_id_pk']."'>".$row['member_name']."</option>";
										}
										else
										{
											echo "<option value='".$row['member_id_pk']."'>".$row['member_name']."</option>";
										}
									}
								}
								?>  
				        	</select>
				      	</div>
	      	
				      	<div class="col-sm-6" style="margin-top:10px;">
				        	<textarea class="form-control form-control-user" id="hobbyDetail" name="hobbyDetail" placeholder="hobby Detail"><?php echo $memcountrow['hobby_detail'];?></textarea>
				      	</div>
		  			
        </div>
   
        <button class="btn btn-primary btn-user btn-block" name="btnCreate">
          Update hobby
        </button>
        <?php
		  			
				}
			}
		  			?>
        <hr>
       
    </form>
	</div>