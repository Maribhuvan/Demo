<?php
$errorMessage="";
						
if(isset($_POST['btnCreate']))
{
	$memberId=$_POST['memberId'];
	$hobbyDetail=$_POST['hobbyDetail'];
	
	
	//$updateQuery="DELETE from tbl_member_hobby where hobby_id='".$_POST['txtdelete_pk']."'";//
	$updateQuery="Update tbl_member_hobby set visibility=0 where hobby_id='".$_POST['txtdelete_pk']."'";
	$con->query($updateQuery);
	
	$errorMessage='	<div class="card mb-4 py-3 border-left-success">
	            			<div class="card-body">Hobbies deleted successfully</div>
	              		</div>';
	?>
	<script>window.location="index.php?page=6";</script>
	<?php	
}
?>
<div class="col-sm-12 mb-3 mb-sm-0">
<?php 
	if($errorMessage!="")
	{
		echo $errorMessage	;				  
	}
?>
	<form method="POST" >
        <div class="form-group row">
			<?php
				if(isset($_POST['txtdelete_pk']))
				{
					$memcountsql = "select * from tbl_member_hobby where hobby_id='".$_POST['txtdelete_pk']."'";
					$memcountresult = $con->query($memcountsql);
					if ($memcountresult->num_rows > 0) 
					{
						while($memcountrow = $memcountresult->fetch_assoc()) 
						{
			?>
						<input type="hidden" name="txtdelete_pk" id="txtdelete_pk" value="<?php echo $memcountrow['hobby_id'];?>">
				      	<div class="col-sm-6 mb-3 mb-sm-0" style="margin-top:10px;">
				      		<label>Member Name</label> &nbsp; &nbsp; &nbsp; &nbsp;
				      		<select id="memberId" name="memberId" value="<?php echo $memcountrow['member_id'];?>">
				      			<option>--Select--</option>
				      			<?php
				      			$query = "SELECT member_name,member_id_pk FROM tbl_member_master;";
								$memberResult = $con->query($query);
				      			while ($row = mysqli_fetch_assoc($memberResult))
								{
									if($memcountrow['member_id_fk'] == $row['member_id_pk'])
									{
								    	echo "<option selected value='".$row['member_id_pk']."'>".$row['member_name']."</option>";
									}
									else
									{
								    	echo "<option value='".$row['member_id_pk']."'>".$row['member_name']."</option>";
									}
								}
								?>  
				        	</select>
				      	</div>
	      	
				      	<div class="col-sm-6" style="margin-top:10px;">
				        	<textarea class="form-control form-control-user" id="hobbyDetail" name="hobbyDetail" placeholder="hobby Detail"><?php echo $memcountrow['hobby_detail'];?></textarea>
				      	</div>
		  			
        </div>
   
        <button class="btn btn-primary btn-user btn-block" name="btnCreate">
          Delete hobby
        </button>
        <?php
		  			}
				}
			}
		  			?>
        <hr>
       
    </form>
		</div>