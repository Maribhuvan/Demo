<?php
$errorMessage="";
if(isset($_POST['btnCreate']))
{
	$memberId=$_POST['memberId'];
	$hobbyDetail=$_POST['hobbyDetail'];
	
	if(checkMemberExists($memberId,$con) ==0)
	{
		$insertQuery="insert into tbl_member_hobby(member_id_fk,hobby_detail) values('".$memberId."','".$hobbyDetail."')";
		$con->query($insertQuery);
		$errorMessage='<div class="card mb-4 py-3 border-left-success">
	                <div class="card-body">
	                  Hobbies added successfully
	                </div>
	              </div>';
	}
	else
	{
		$errorMessage='<div class="card mb-4 py-3 border-left-danger">
	                <div class="card-body">
	                  Hobby detail already exists for this member
	                </div>
	              </div>';
	}
}

function checkMemberExists($memberId,$con)
{
	$exists=0;
	$memcountsql = "select count(*)as membercount from tbl_member_hobby where member_id_fk='".$memberId."' and visibility =1";
						$memcountresult = $con->query($memcountsql);

						
	while($memcountrow = $memcountresult->fetch_assoc()) 
	{
		if($memcountrow['membercount']>0)
		{
			$exists=1;
		}
	}
	
	
	return $exists;
}
?>
<div class="col-sm-12 mb-3 mb-sm-0">
<?php 
				  if($errorMessage!="")
				  {
						echo $errorMessage	;				  
				  }
				  ?>
<form method="POST" >
                <div class="form-group row" style="margin-top:50px;">
                  <div class="col-sm-6 mb-3 mb-sm-0" >
                  	<?php 
	                  	$query = "SELECT member_name,member_id_pk FROM tbl_member_master;";
						$memberResult = $con->query($query);
					?>
					
					<select class="form-control form-control-user" name="memberId" id="memberId" >
						<option value="">--Select--</option>
						<?php 
						while ($row = mysqli_fetch_assoc($memberResult))
						{
						    echo "<option value='".$row['member_id_pk']."'>".$row['member_name']."</option>";
						}
						?>        
					</select>
                  </div>
                  <div class="col-sm-6">
                    <input class="form-control form-control-user" id="hobbyDetail" name="hobbyDetail" placeholder="Hobby detail">
					</input>
                  </div>
                </div>
               
                <button class="btn btn-primary btn-user btn-block" name="btnCreate">
                  Add hobby
                </button>
                <hr>
               
              </form>
			  </div>