<?php
if(isset($_SESSION['loggedin']))
{
	if($_SESSION['loggedin']==0)
	{
			header("Location: login.php");
	}
}
?>