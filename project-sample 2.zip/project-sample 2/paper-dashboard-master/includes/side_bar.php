<div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="assets/img/logo-small.png">
          </div>
        </a>
        <a href="#" class="simple-text logo-normal">
          A d m i n
          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
		
		<!-- Divider -->
      
        
      </div>
	     <!-- Heading -->
		
   
     
	 <div class="sidebar-wrapper"><br>
		   <a class="nav-link" href="index.php">
          
		  <i class="fa fa-fw fa-tachometer-alt"></i>
          <span><?php echo getDefValue('dashboard_title',$con);?></span></a>
        <ul class="nav">
          <?php
		$menusql = "select * from tbl_menu order by menu_order asc";
		$menuresult = $con->query($menusql);

		if ($menuresult->num_rows > 0) 
		{
			while($menurow = $menuresult->fetch_assoc()) 
			{
					?>
					  <li class="nav-item">
						<a class="nav-link" href="index.php?page=<?php echo $menurow['menu_id'];?>">
						  <i class="<?php echo $menurow['menu_icon'];?>"></i>
						  <span><?php echo $menurow['menu_name'];?></span></a>
					  </li>
					<?php
			}
		} 
	  ?>
	 
        
          
          
         
        
        </ul>
