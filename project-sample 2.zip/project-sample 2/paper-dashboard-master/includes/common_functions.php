<?php
//function to get definition value

function getDefValue($defType,$con)
{
	$sql = "select def_value from tbl_project_details where def_types='".$defType."'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) 
	{
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
			return $row['def_value'];
		}
	} 
	else 
	{
		return "Member";
	}
}
function getTitle($page,$con)
{
	$sql = "select menu_title from tbl_menu where menu_id='".$page."'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) 
	{
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
			return $row['menu_title'];
		}
	} 
	else 
	{
		return "Dashboard";
	}
}


function getPage($menu_id,$con)
{
	$sql = "select cont_folder,cont_page from tbl_controller where cont_menu_id='".$menu_id."'";
	$result = $con->query($sql);

	if ($result->num_rows > 0) 
	{
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
			//echo $row['cont_folder'].$row['cont_page'];
			return $row['cont_folder'].$row['cont_page'];
		}
	} 
	else 
	{
		return "modules/dashboard.php";
	}
}

function getMemberName($memberid,$con)
{
	$memberName='';
	 $memcountsql = "select * from tbl_member_master where member_id_pk='".$memberid."'";
				  $memcountresult = $con->query($memcountsql);

				 if ($memcountresult->num_rows > 0) 
						{
							while($memcountrow = $memcountresult->fetch_assoc()) 
							{
								$memberName=$memcountrow['member_name'];
							}
						}
return $memberName;
}
?>